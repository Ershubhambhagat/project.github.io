import './App.css';
import Resturent from './Component/basic/Resturent';

function App() {
  return (
    <>

      <Resturent />


    </>
  );
}

export default App;
